/* ============================================================
   脐橙庄园 · 数据层 (localStorage)
   供顾客端与管理端共用，模拟真实后端
   ============================================================ */
(function (global) {
  "use strict";

  const KEY = "orange_shop_db_v1";

  /* ---------- 商品定义 ---------- */
  const PRODUCTS = [
    {
      id: "P01", name: "特级脐橙·果王", grade: "特级果",
      price: 88, unit: "箱", img: "assets/images/p-grade1.jpg",
      desc: "果径80mm以上，单果约280g，糖度14°+，皮薄多汁，送礼自留两相宜。",
      specs: ["10斤装", "20斤装"],
      tags: ["当季鲜果", "送礼推荐"]
    },
    {
      id: "P02", name: "一级脐橙·精选", grade: "一级果",
      price: 58, unit: "箱", img: "assets/images/p-grade2.jpg",
      desc: "果径70-80mm，手工筛选，酸甜均衡，家庭日常口粮首选。",
      specs: ["10斤装", "20斤装"],
      tags: ["高性价比", "家庭装"]
    },
    {
      id: "P03", name: "精品礼盒·心意装", grade: "礼盒装",
      price: 128, unit: "盒", img: "assets/images/p-giftbox.jpg",
      desc: "12枚精装礼盒，烫金提袋，附手写卡片，节日送礼体面之选。",
      specs: ["12枚装", "24枚装"],
      tags: ["节日礼品", "含卡片"]
    },
    {
      id: "P04", name: "脐橙鲜榨·整箱果", grade: "大果装",
      price: 46, unit: "箱", img: "assets/images/p-grade2.jpg",
      desc: "果径65mm以上，出汁率高，适合鲜榨果汁、果切，量大从优。",
      specs: ["20斤装", "40斤装"],
      tags: ["鲜榨专用", "量大从优"]
    }
  ];

  /* ---------- 省份与物流公司 ---------- */
  const PROVINCES = ["北京市", "上海市", "广东省", "浙江省", "江苏省", "福建省", "山东省", "四川省", "湖北省", "湖南省", "河南省", "安徽省", "江西省", "重庆市", "陕西省", "辽宁省", "云南省", "广西壮族自治区", "其他"];
  const SOURCES = ["微信私聊", "朋友圈", "朋友推荐", "公众号", "抖音", "老客复购", "搜索"];
  const LOGISTICS = ["顺丰速运", "京东物流", "中通快递", "圆通速递", "邮政EMS", "德邦快递"];

  /* ---------- 真实感姓名/电话/地址 ---------- */
  const SURNAMES = ["李", "王", "张", "刘", "陈", "杨", "黄", "赵", "吴", "周", "徐", "孙", "马", "朱", "胡", "林", "郭", "何", "高", "罗"];
  const GIVENS = ["伟", "芳", "娜", "敏", "静", "丽", "强", "磊", "军", "洋", "勇", "艳", "杰", "娟", "涛", "明", "霞", "平", "刚", "桂英"];
  const CITIES = [
    { p: "广东省", c: ["广州市", "深圳市", "东莞市", "佛山市"], d: ["天河区", "南山区", "长安镇", "禅城区"], a: ["体育西路", "科技园路", "锦绣路", "季华路"] },
    { p: "浙江省", c: ["杭州市", "宁波市", "温州市"], d: ["西湖区", "鄞州区", "鹿城区"], a: ["文三路", "四明中路", "车站大道"] },
    { p: "江苏省", c: ["南京市", "苏州市", "无锡市"], d: ["鼓楼区", "姑苏区", "梁溪区"], a: ["中山路", "干将路", "人民路"] },
    { p: "北京市", c: ["北京市"], d: ["朝阳区", "海淀区", "丰台区"], a: ["建国路", "中关村大街", "南三环"] },
    { p: "四川省", c: ["成都市", "绵阳市"], d: ["锦江区", "涪城区"], a: ["春熙路", "临园路"] },
    { p: "湖北省", c: ["武汉市"], d: ["武昌区", "洪山区"], a: ["中南路", "珞狮路"] },
    { p: "福建省", c: ["福州市", "厦门市"], d: ["鼓楼区", "思明区"], a: ["八一七路", "鹭江道"] },
    { p: "山东省", c: ["济南市", "青岛市"], d: ["历下区", "市南区"], a: ["泉城路", "香港中路"] }
  ];

  function rnd(a) { return a[Math.floor(Math.random() * a.length)]; }
  function rndInt(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
  function pad(n, w) { return String(n).padStart(w, "0"); }

  function genName() { return rnd(SURNAMES) + rnd(GIVENS); }
  function genPhone() { return "1" + rnd(["3", "5", "7", "8", "9"]) + String(rndInt(100000000, 999999999)).slice(0, 9); }
  function genAddr() {
    const ci = rnd(CITIES);
    const d = rnd(ci.d), a = rnd(ci.a);
    return { province: ci.p, city: rnd(ci.c), district: d, address: a + rndInt(1, 220) + "号" + rndInt(1, 30) + "栋" + rndInt(101, 2099) + "室" };
  }

  /* ---------- 生成种子订单（日期相对当前，保证预览有数据） ---------- */
  function dayOffset(days, h, m) {
    const d = new Date();
    d.setDate(d.getDate() - days);
    d.setHours(h || rndInt(8, 21), m || rndInt(0, 59), 0, 0);
    return d.getTime();
  }

  function buildOrder(seq, daysAgo, forceStatus) {
    const p = rnd(PRODUCTS);
    const spec = rnd(p.specs);
    const qty = rndInt(1, 4);
    const addr = genAddr();
    const statusPool = forceStatus || rnd(["paid", "paid", "paid", "shipped", "pending", "done"]);
    const ts = dayOffset(daysAgo);
    const no = "NC" + new Date(ts).getFullYear() + pad(new Date(ts).getMonth() + 1, 2) + pad(new Date(ts).getDate(), 2) + pad(seq, 4);
    const unitMul = spec.indexOf("40") > -1 ? 4 : spec.indexOf("20") > -1 ? 2 : 1;
    const subtotal = p.price * qty * unitMul;
    const o = {
      id: no,
      createdAt: ts,
      customer: { name: genName(), phone: genPhone(), ...addr },
      items: [{ productId: p.id, name: p.name, spec, price: p.price * unitMul, qty, subtotal }],
      totalAmount: subtotal,
      freight: 0,
      payStatus: statusPool === "pending" ? "pending" : "paid",
      shipStatus: statusPool === "pending" ? "pending" : statusPool === "shipped" ? "shipped" : statusPool === "done" ? "done" : "pending",
      shippingNo: statusPool === "shipped" || statusPool === "done" ? rnd(LOGISTICS).slice(0, 1) + "T" + rndInt(100000000, 999999999) : "",
      logisticsCompany: statusPool === "shipped" || statusPool === "done" ? rnd(LOGISTICS) : "",
      source: rnd(SOURCES),
      remark: rnd(["", "", "请尽快发货", "送人，包装好一点", "周末送达", "不要放快递柜", "打电话提前联系"]),
      internalNote: rnd(["", "", "老客户", "团购", "加急处理"])
    };
    // 偶尔多商品
    if (Math.random() < 0.25) {
      const p2 = rnd(PRODUCTS);
      const sp2 = rnd(p2.specs), q2 = rndInt(1, 2);
      const mul2 = sp2.indexOf("40") > -1 ? 4 : sp2.indexOf("20") > -1 ? 2 : 1;
      o.items.push({ productId: p2.id, name: p2.name, spec: sp2, price: p2.price * mul2, qty: q2, subtotal: p2.price * mul2 * q2 });
      o.totalAmount += p2.price * mul2 * q2;
    }
    return o;
  }

  function seedOrders() {
    const arr = [];
    let seq = 1;
    // 今天 6 单
    for (let i = 0; i < 6; i++) arr.push(buildOrder(seq++, 0, i < 2 ? "pending" : i === 2 ? "shipped" : "paid"));
    // 昨天 9 单
    for (let i = 0; i < 9; i++) arr.push(buildOrder(seq++, 1, i < 4 ? "shipped" : i > 7 ? "done" : "paid"));
    // 前天 7 单
    for (let i = 0; i < 7; i++) arr.push(buildOrder(seq++, 2, i < 3 ? "shipped" : i > 5 ? "done" : "paid"));
    // 更早散单
    for (let d = 3; d <= 8; d++) { const n = rndInt(2, 6); for (let i = 0; i < n; i++) arr.push(buildOrder(seq++, d)); }
    return arr;
  }

  function seedInventory() {
    return PRODUCTS.map(p => ({
      productId: p.id, name: p.name, img: p.img,
      total: p.id === "P03" ? 500 : 2000, // 礼盒库存少
      sold: p.id === "P03" ? 312 : p.id === "P02" ? 1680 : 420,
      threshold: p.id === "P03" ? 80 : 200
    }));
  }

  /* ---------- 读写 ---------- */
  function load() {
    let raw = localStorage.getItem(KEY);
    if (!raw) {
      const db = { products: PRODUCTS, orders: seedOrders(), inventory: seedInventory(), seq: 1 };
      localStorage.setItem(KEY, JSON.stringify(db));
      return db;
    }
    try { return JSON.parse(raw); } catch (e) { localStorage.removeItem(KEY); return load(); }
  }
  function save(db) { localStorage.setItem(KEY, JSON.stringify(db)); }

  let db = load();

  /* ---------- 顾客端 API ---------- */
  const api = {
    PRODUCTS, PROVINCES, SOURCES, LOGISTICS,

    getProducts() { return db.products; },
    getProduct(id) { return db.products.find(p => p.id === id); },

    /* 购物车（存在 localStorage 独立键） */
    getCart() {
      try { return JSON.parse(localStorage.getItem("orange_cart") || "[]"); }
      catch (e) { return []; }
    },
    saveCart(cart) { localStorage.setItem("orange_cart", JSON.stringify(cart)); },
    addToCart(productId, spec, qty) {
      const p = this.getProduct(productId); if (!p) return;
      const cart = this.getCart();
      const mul = spec.indexOf("40") > -1 ? 4 : spec.indexOf("20") > -1 ? 2 : 1;
      const exist = cart.find(i => i.productId === productId && i.spec === spec);
      if (exist) { exist.qty += qty; }
      else cart.push({ productId, name: p.name, spec, price: p.price * mul, img: p.img, qty });
      this.saveCart(cart);
    },
    setQty(index, qty) {
      const cart = this.getCart();
      if (index < 0 || index >= cart.length) return;
      if (qty <= 0) { cart.splice(index, 1); } else { cart[index].qty = qty; }
      this.saveCart(cart);
    },
    clearCart() { localStorage.setItem("orange_cart", "[]"); },

    /* 下单 */
    placeOrder(form) {
      const cart = this.getCart();
      if (!cart.length) return null;
      const items = cart.map(i => ({ productId: i.productId, name: i.name, spec: i.spec, price: i.price, qty: i.qty, subtotal: i.price * i.qty }));
      const total = items.reduce((s, i) => s + i.subtotal, 0);
      const now = Date.now();
      const d = new Date(now);
      db.seq = (db.seq || 1);
      const no = "NC" + d.getFullYear() + pad(d.getMonth() + 1, 2) + pad(d.getDate(), 2) + pad(++db.seq, 4);
      const order = {
        id: no, createdAt: now,
        customer: { name: form.name, phone: form.phone, province: form.province, city: form.city, district: form.district, address: form.address },
        items, totalAmount: total, freight: 0,
        payStatus: "pending", shipStatus: "pending",
        shippingNo: "", logisticsCompany: "",
        source: form.source || "微信私聊",
        remark: form.remark || "", internalNote: ""
      };
      db.orders.unshift(order);
      // 扣库存
      items.forEach(it => {
        const inv = db.inventory.find(v => v.productId === it.productId);
        if (inv) inv.sold += it.qty;
      });
      save(db);
      this.clearCart();
      return order;
    },

    /* ---------- 管理端 API ---------- */
    getOrders(filter) {
      let list = db.orders.slice();
      if (filter) {
        if (filter.date) {
          const start = new Date(filter.date); start.setHours(0, 0, 0, 0);
          const end = new Date(filter.date); end.setHours(23, 59, 59, 999);
          list = list.filter(o => o.createdAt >= start.getTime() && o.createdAt <= end.getTime());
        }
        if (filter.range) { list = list.filter(o => o.createdAt >= filter.range[0] && o.createdAt <= filter.range[1]); }
        if (filter.pay) list = list.filter(o => o.payStatus === filter.pay);
        if (filter.ship) list = list.filter(o => o.shipStatus === filter.ship);
        if (filter.q) {
          const q = filter.q.trim().toLowerCase();
          list = list.filter(o => o.id.toLowerCase().includes(q) || o.customer.name.includes(q) || o.customer.phone.includes(q) || o.customer.address.includes(q));
        }
      }
      return list.sort((a, b) => b.createdAt - a.createdAt);
    },
    getOrder(id) { return db.orders.find(o => o.id === id); },
    updateOrder(id, patch) {
      const o = db.orders.find(x => x.id === id); if (!o) return;
      Object.assign(o, patch); save(db);
    },
    deleteOrder(id) {
      const i = db.orders.findIndex(o => o.id === id);
      if (i > -1) { db.orders.splice(i, 1); save(db); }
    },

    getCustomers() {
      const map = new Map();
      db.orders.forEach(o => {
        const k = o.customer.phone;
        if (!map.has(k)) map.set(k, { phone: k, name: o.customer.name, address: `${o.customer.province}${o.customer.city}${o.customer.district}${o.customer.address}`, orders: 0, total: 0, lastAt: 0, source: o.source });
        const c = map.get(k);
        c.orders++; c.total += o.totalAmount; c.lastAt = Math.max(c.lastAt, o.createdAt);
      });
      return Array.from(map.values()).sort((a, b) => b.total - a.total);
    },

    getInventory() { return db.inventory; },
    updateStock(productId, total) {
      const inv = db.inventory.find(v => v.productId === productId);
      if (inv) { inv.total = Math.max(0, total | 0); save(db); }
    },

    /* 概览统计 */
    getOverview(date) {
      const start = date ? new Date(date).setHours(0, 0, 0, 0) : new Date().setHours(0, 0, 0, 0);
      const end = date ? new Date(date).setHours(23, 59, 59, 999) : new Date().setHours(23, 59, 59, 999);
      const todays = db.orders.filter(o => o.createdAt >= start && o.createdAt <= end);
      const orderCount = todays.length;
      const revenue = todays.reduce((s, o) => s + (o.payStatus === "paid" ? o.totalAmount : 0), 0);
      const pendingShip = todays.filter(o => o.payStatus === "paid" && o.shipStatus === "pending").length;
      const totalKg = todays.reduce((s, o) => s + o.items.reduce((x, i) => x + (i.spec.indexOf("40") > -1 ? 40 : i.spec.indexOf("20") > -1 ? 20 : 10) * i.qty, 0), 0);
      // 热销
      const prodMap = {};
      todays.forEach(o => o.items.forEach(i => { prodMap[i.name] = (prodMap[i.name] || 0) + i.qty; }));
      const hot = Object.entries(prodMap).sort((a, b) => b[1] - a[1]).slice(0, 3);
      return { orderCount, revenue, pendingShip, totalKg, hot };
    },

    /* 导出 CSV（带 BOM，Excel 直接打开不乱码） */
    exportCSV(orders) {
      const head = ["订单号", "下单时间", "客户姓名", "联系电话", "省份", "城市", "区县", "详细地址", "商品", "规格", "单价", "数量", "金额", "支付状态", "发货状态", "物流公司", "物流单号", "订单来源", "客户备注", "内部备注"];
      const rows = orders.map(o => {
        const t = new Date(o.createdAt);
        const tstr = `${t.getFullYear()}-${pad(t.getMonth() + 1, 2)}-${pad(t.getDate(), 2)} ${pad(t.getHours(), 2)}:${pad(t.getMinutes(), 2)}`;
        const itemsStr = o.items.map(i => i.name).join(" + ");
        const specStr = o.items.map(i => i.spec).join(" + ");
        const priceStr = o.items.map(i => i.price).join(" + ");
        const qtyStr = o.items.map(i => i.qty).join(" + ");
        return [o.id, tstr, o.customer.name, o.customer.phone, o.customer.province, o.customer.city, o.customer.district, o.customer.address,
          itemsStr, specStr, priceStr, qtyStr, o.totalAmount,
          this.payLabel(o.payStatus), this.shipLabel(o.shipStatus), o.logisticsCompany, o.shippingNo, o.source, o.remark, o.internalNote];
      });
      const all = [head, ...rows];
      const csv = all.map(r => r.map(c => {
        const s = String(c == null ? "" : c);
        return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
      }).join(",")).join("\r\n");
      return "\uFEFF" + csv;
    },

    download(filename, content, mime) {
      const blob = new Blob([content], { type: (mime || "text/plain") + ";charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = filename; document.body.appendChild(a); a.click();
      document.body.removeChild(a); URL.revokeObjectURL(url);
    },

    /* 标签 */
    payLabel(s) { return { paid: "已支付", pending: "待付款" }[s] || s; },
    shipLabel(s) { return { pending: "待发货", shipped: "已发货", done: "已完成", cancel: "已取消" }[s] || s; },

    fmtTime(ts) { const d = new Date(ts); return `${d.getFullYear()}-${pad(d.getMonth() + 1, 2)}-${pad(d.getDate(), 2)} ${pad(d.getHours(), 2)}:${pad(d.getMinutes(), 2)}`; },
    fmtDate(ts) { const d = new Date(ts); return `${d.getFullYear()}-${pad(d.getMonth() + 1, 2)}-${pad(d.getDate(), 2)}`; },
    money(n) { return "¥" + Number(n).toLocaleString("zh-CN"); },
    todayStr() { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1, 2)}-${pad(d.getDate(), 2)}`; }

  };

  global.Store = api;
})(window);
